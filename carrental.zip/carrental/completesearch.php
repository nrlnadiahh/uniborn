<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Kereta Sewa Abang</title>
	<?php include 'head.php';?>
	<script type="text/javascript">
			function confirmDelete(bookingid)
			{
				if(confirm('Sure To Remove This Record ?'))
				{
					window.location.href='deletebooking.php?bookingid='+bookingid;
				}
			}
		</script>

</head>

<body>
<div class="tm-bg-transparent-black tm-contact-box-pad1">
    <div class="row mb-4">
		<div class="col-sm-12">
		    <section>
			<article>
					<div class="tm-bg-transparent-black tm-contact-box-pad1">
    <div class="row mb-4">
		<div class="col-sm-12">
			<header><h2 class="tm-text-shadow">Search Field </h2></header>
		</div>
	</div>
	<div class="contact_message">
			<form action="completesearchaction.php" method="GET" class="contact-form">
				<div class="form-group">
							<input type="text"  name="searchfield" class="form-control" placeholder="Search Data from Booking" required>
				</div>
											
				<button type="submit" class="btn tm-btn-submit tm-btn ml-auto">Submit</button>
			</form>
      </div>
</div>
								
								
                                 
			</article>
		</section>
		</div>
	</div>
</div>                            
									
				<footer class="footer-link">
                      <?php include 'footer.php'; ?>
				</footer>

	</body>
</html>