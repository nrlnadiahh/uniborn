<div class="tm-bg-transparent-black tm-contact-box-pad">
    <div class="row mb-4">
		<div class="col-sm-12">
			<center><h2 class="tm-text-shadow2"><b>Search Field</b></h2></center>
			<br>
			
				
			<a href="completesearch.php" class="btn tm-btn1 tm-font-big" data-nav-link="#tmNavLink2">Completed</a>  
			<a href="pendingsearch.php" class="btn tm-btn1 tm-font-big" data-nav-link="#tmNavLink2">Pending</a>    
			<a href="rejectedsearch.php" class="btn tm-btn1 tm-font-big" data-nav-link="#tmNavLink2">Rejected</a>   
		
		</div>
	</div>
</div>   
								
								
                                 