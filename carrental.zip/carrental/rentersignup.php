<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Kereta Sewa Abang</title>
	<?php include 'head.php';?>
</head>

<body>
			<center><header><h2 class="tm-text-shadow7"></h2></header></center>
		
	<section  class="tm-sectionS">
			<div class="tm-bg-transparent-black tm-contact-box-pad">
   				 <div class="row mb-4">
					<div class="col-sm-12">
						<center><h2 class="tm-text-shadow7">Sign Up</h2></center>
					</div>
				</div>
			<div class="contact_message">
				<form action="rentersignupaction.php" id="form" method="POST">
					<div class="form-group">
						<input type="text"  name="rentername" maxlength="50"  class="form-control" placeholder="Full Name" required>
					</div>
					<div class="form-group">
						<input type="text"  name="icnum" class="form-control" placeholder="IC Number, ie 000414-01-0612" required>
					</div>
					<div class="form-group">
						<input type="text"  name="phonenum" class="form-control" placeholder="Phone Number, ie 011-10816090" required>
					</div>
					<div class="form-group">
						<input type="text"  name="licensenum" class="form-control" placeholder="License Number, ie 66542789" required>
					</div>
					<div class="form-group">
						<textarea id="contact_message" name="address" class="form-control" rows="4" placeholder="Address" required></textarea>					</div>
					</div>
					<div class="form-group">
						<input type="email"  name="email" class="form-control" placeholder="Email" required>
					</div>
					<div class="form-group">
						<input type="password"  name="password" class="form-control" placeholder="Password" required>
					</div>
					<center>
					<input type="submit" value="Sign Up">
					<input type="reset" value="Reset"> 
					<div>
                			<p>Have an account? <a href="renterlogin.php">Login</a></p>
                	</div></center>
			</form>
      </div>
</div>
</section>
<br>
<br>
<br>
				<footer class="footer-link">
                      <?php include 'footer.php'; ?>
				</footer>

	</body>
</html>