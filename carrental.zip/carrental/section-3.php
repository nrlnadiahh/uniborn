<!-- <div class="row mb-4">
							<header class="col-xl-12"><h2 class="tm-text-shadow">Our Company</h2></header>		
						</div>
						<div class="row">
							<div class="col-sm-12 col-md-6 col-lg-12 col-xl-6 mb-4">
								<div class="media tm-bg-transparent-black tm-border-white">
									<i class="fab fa-apple tm-icon-circled tm-icon-media"></i>
									<div class="media-body">
										<h3>HTML Templates</h3>
										<p>We provide a variety of templates for you at no cost. Please spread a word about <a href="https://plus.google.com/+tooplate" target="_parent">Tooplate</a> website. Thank you.</p>	
									</div>
								</div>
							</div>	
							<div class="col-sm-12 col-md-6 col-lg-12 col-xl-6 mb-4">
								<div class="media tm-bg-transparent-black tm-border-white">
									<i class="fas fa-map-pin mr-4 tm-icon-circled tm-icon-media"></i>	
									<div class="media-body">
										<h3>Free Images</h3>
										<p>Photos by <a href="https://unsplash.com" target="_blank">Unsplash.com</a> website, ac ornare arcu finibus sed. Aenean ultrices nisi sit amet facilisis viverra.</p>	
									</div>
								</div>
							</div>
							<div class="col-sm-12 col-md-6 col-lg-12 col-xl-6 mb-4">
								<div class="media tm-bg-transparent-black tm-border-white">
									<i class="fab fa-fly mr-4 tm-icon-circled tm-icon-media"></i>
									<div class="media-body">
										<h3>Phasellus eleifend</h3>
										<p>Phasellus feugiat scelerisque sapien, ac ornare arcu finibus sed. Aenean ultrices nisi sit amet facilisis viverra.</p>		
									</div>
								</div>
							</div>
							<div class="col-sm-12 col-md-6 col-lg-12 col-xl-6 mb-4">
								<div class="media tm-bg-transparent-black tm-border-white">
									<i class="fab fa-linode mr-4 tm-icon-circled tm-icon-media"></i>
									<div class="media-body">
										<h3>Phasellus eleifend</h3>
										<p>Phasellus feugiat scelerisque sapien, ac ornare arcu finibus sed. Aenean ultrices nisi sit amet facilisis viverra.</p>	
									</div>
								</div>
							</div>			          		
                        </div>	-->

                        
                        <div>
							<header class="mb-4"><h2 class="tm-text-shadow3">Vehicles</h2></header>		            
							<div class="tm-img-container">
								<div class="tm-img-slider">
									<a href="img/myvi.jpg" class="tm-slider-img"><img src="img/myvi.jpg" alt="Image" class="img-fluid"></a>
									<a href="img/saga.jpg" class="tm-slider-img"><img src="img/saga.jpg" alt="Image" class="img-fluid"></a>
									<a href="img/blue.jpg" class="tm-slider-img"><img src="img/blue.jpg" alt="Image" class="img-fluid"></a>
									<a href="img/axia.jpg" class="tm-slider-img"><img src="img/axia.jpg" alt="Image" class="img-fluid"></a>
									<a href="img/exora.jpg" class="tm-slider-img"><img src="img/exora.jpg" alt="Image" class="img-fluid"></a>
									<a href="img/alza.jpg" class="tm-slider-img"><img src="img/alza.jpg" alt="Image" class="img-fluid"></a>
									<a href="img/hiace.jpg" class="tm-slider-img"><img src="img/hiace.jpg" alt="Image" class="img-fluid"></a>

								</div>
                            </div>	       		          
                        </div>  
                        <br>   
                        <a href="displayvehicle.php" class="btn tm-btn tm-font-big" data-nav-link="#tmNavLink2">Details...</a> 	     