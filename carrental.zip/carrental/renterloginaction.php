<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Kereta Sewa Abang</title>
	<?php include 'head.php';?>
</head>

<body>

			
		
	<section>
			<article>
			<?php 
			include 'conn.php';
			$conn = OpenCon();
				session_start();
				$renterid = $_POST["renterid"];
				$password = $_POST["password"];

				$sql = "SELECT * from renter WHERE renterid = '$renterid'	and password = '$password'";
				$result = $conn->query($sql);
				if($result-> num_rows > 0) {
					
					//output data of each row
					while($row = $result->fetch_assoc()){
						$_SESSION['login_user'] = $renterid;
						
						header("location: cardoor/index.php");
					}
				} else {
					include 'renterlogin.php';
					 $message = "Renter ID or Password is incorrect.\\n               Please try again.";
					echo "<script type='text/javascript'>alert('$message');</script>";
				  
				}
				CloseCon($conn);
			?>
			</article>
		</section>

				<footer class="footer-link">
                      <?php include 'footer.php'; ?>
				</footer>

	</body>
</html>