<li>
    <a href="home.php" id="tmNavLink1" class="scrolly" data-bg-img="banner2.jpg" data-page="#tm-section-1">
        <i class="fas fa-home tm-nav-fa-icon"></i>
        <span>Homepage</span>
	</a>
</li>
<li>
    <a href="#customer" id="tmNavLink2" class="scrolly" data-bg-img="banner2.jpg" data-page="#tm-section-2" data-page-type="carousel">
        <i class="fas fa-list-ol tm-nav-fa-icon"></i>
        <span>Bookings</span>
    </a>
</li>							
<li>
    <a href="#company" class="scrolly" data-bg-img="banner2.jpg" data-page="#tm-section-3">
        <i class="fas fa-car tm-nav-fa-icon"></i>
        <span>Vehicles</span>
    </a>
</li>
<li>
    <a href="#contact" class="scrolly" data-bg-img="banner2.jpg" data-page="#tm-section-4">
        <i class="fas fa-search tm-nav-fa-icon"></i>
        <span>Search</span>
	</a>
</li>
<li>
    <a href="#company" class="scrolly" data-bg-img="banner2.jpg" data-page="#tm-section-5">
        <i class="fas fa-users tm-nav-fa-icon"></i>
        <span>My Profile</span>
    </a>
</li>