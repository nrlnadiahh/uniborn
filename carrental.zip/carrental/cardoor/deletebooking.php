<body>

		    <section>
			<article>
				<?php

				include 'conn.php';
				$bookingid = $_GET["bookingid"];
				$conn = OpenCon();

				$sql = "delete from booking where bookingid = '$bookingid'";
				
				$result = $conn->query($sql);

				if(! $result) {
					die('Could not delete data: ' . mysqli_error());
				}
				else {
					 echo ("<script type='text/javascript'>alert('Booking has been deleted');window.location.href='index.php';</script>");
				}

				?>
				
			</article>
		</section>
	
	</body>