<!DOCTYPE html>
<html class="no-js" lang="zxx">

<head>
    <?php include 'head.php'; ?>
</head>

<body class="loader-active">
     <!--== Preloader Area Start ==-->
     <div class="preloader">
        <div class="preloader-spinner">
            <div class="loader-content">
                <img src="assets/img/preloader.gif" alt="JSOFT">
            </div>
        </div>
    </div>
    <!--== Preloader Area End ==-->
 
    <!--== Header Area Start ==-->
    <?php include 'header.php'; ?>
    <!--== Header Area End ==-->

    
    <!--== SlideshowBg Area Start ==-->
    <section id="slideslow-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="slideshowcontent">
                        <div class="display-table">
                            <div class="display-table-cell">
                                <h1>BOOK A CAR TODAY!</h1>
                                <p>FOR AS LOW AS RM7 A DAY</p>

                                <div class="book-ur-car">
                                    <form action="displaycardetails.php" method="POST">
                                        <div class="bookinput-item">
                                        <label>-PICK UP LOCATION-</label>
                                            <select id="picklocation" name="picklocation" >
                                              <option value="Bus Terminal">Bus Terminal</option>
                                              <option value="International Airport">International Airport</option>
                                              <option value="Ferry Terminal">Ferry Terminal</option>
                                              <option value="Self Collect at Center">Self Collect at Center</option>
                                              
                                            </select>
                                        </div>
                                        <div class="pick-date bookinput-item">
                                        <label>-BOOKING DATE-</label>
                                             <input type="date" name="bookdate" min="<?= date('Y-m-d'); ?>" value= "<?= date('Y-m-d'); ?>" required>
                                        </div>
                                        
                                        <div class="bookinput-item">
                                           <label>-TIME IN-</label>
                                             <input type="time" id="timein" name="timein" value="08:00" required>
                                        </div>
                                

                                        
                                        <div class="bookinput-item">
                                           <label>-TIME OUT-</label>
                                            <input type="time" id="timein" name="timeout" value="22:00" required>
                                        </div>

                                        <div class="bookcar-btn bookinput-item">
                                            <button type="submit">Book Car</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--== SlideshowBg Area End ==-->

    <!--== About Us Area Start ==-->
    <section id="about-area" class="section-padding">
        <div class="container">
            <div class="row">
                <!-- Section Title Start -->
                <div class="col-lg-12">
                    <div class="section-title  text-center">
                        <h2>About us</h2>
                        <span class="title-line"><i class="fa fa-car"></i></span>
                        <p>Kereta Sewa Abang (Since 2000)</p>
                    </div>
                </div>
                <!-- Section Title End -->
            </div>

            <div class="row">
                <!-- About Content Start -->
                <div class="col-lg-6">
                    <div class="display-table">
                        <div class="display-table-cell">
                            <div class="about-content">
                                <p>We are Kereta Sewa Abang. Founded in 2000, Kereta Sewa Abang is Malaysia's most distinguished rental car company. We provide customers with variety choice of vehicles for customers to rent. We are the most trusted name in vehicle rentals.</p>

                                <p>In order to provide customers with safety and peace of mind, Kereta Sewa Abang strives to improve quality in two major areas which are vehicle quality and customer service quality. More than just rental cars, we provide customers with a variety of services for satisfaction and peace of mind. </p>
                                <div class="about-btn">
                                    <a href="contact.php">Contact Us</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- About Content End -->

                <!-- About Video Start -->
                <div class="col-lg-6">
                    <div class="about-video">
                        <iframe src="https://player.vimeo.com/video/29358554?title=0&byline=0&portrait=0"></iframe>
                    </div>
                </div>
                <!-- About Video End -->
            </div>
        </div>
    </section>
    <!--== About Us Area End ==-->
    

    <!--== Partner Area Start ==-->
    <div id="partner-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="partner-content-wrap">
                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="assets/img/logocrop1.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                   
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="assets/img/logocrop1.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                   
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    <img src="assets/img/logocrop1.png" alt="JSOFT">
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                        <!-- Single Partner Start -->
                        <div class="single-partner">
                            <div class="display-table">
                                <div class="display-table-cell">
                                    
                                </div>
                            </div>
                        </div>
                        <!-- Single Partner End -->

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--== Partner Area End ==-->

    <!--== Team Area Start ==-->
        <?php include 'teamarea.php'; ?>
    <!--== Team Area End ==-->



    
    <!--== Footer Area Start ==-->
        <?php include'footer.php' ?>
    <!--== Footer Area End ==-->

    <!--== Scroll Top Area Start ==-->
    <div class="scroll-top">
        <img src="assets/img/scroll-top.png" alt="JSOFT">
    </div>
    <!--== Scroll Top Area End ==-->

    <!--=======================Javascript============================-->
    <script src="js/jquery.js"></script> 
    <script src="js/moment.min.js"></script> 
    <script src="js/combodate.js"></script> 
   
    <!--=== Jquery Min Js ===-->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <!--=== Jquery Migrate Min Js ===-->
    <script src="assets/js/jquery-migrate.min.js"></script>
    <!--=== Popper Min Js ===-->
    <script src="assets/js/popper.min.js"></script>
    <!--=== Bootstrap Min Js ===-->
    <script src="assets/js/bootstrap.min.js"></script>
    <!--=== Gijgo Min Js ===-->
    <script src="assets/js/plugins/gijgo.js"></script>
    <!--=== Vegas Min Js ===-->
    <script src="assets/js/plugins/vegas.min.js"></script>
    <!--=== Isotope Min Js ===-->
    <script src="assets/js/plugins/isotope.min.js"></script>
    <!--=== Owl Caousel Min Js ===-->
    <script src="assets/js/plugins/owl.carousel.min.js"></script>
    <!--=== Waypoint Min Js ===-->
    <script src="assets/js/plugins/waypoints.min.js"></script>
    <!--=== CounTotop Min Js ===-->
    <script src="assets/js/plugins/counterup.min.js"></script>
    <!--=== YtPlayer Min Js ===-->
    <script src="assets/js/plugins/mb.YTPlayer.js"></script>
    <!--=== Magnific Popup Min Js ===-->
    <script src="assets/js/plugins/magnific-popup.min.js"></script>
    <!--=== Slicknav Min Js ===-->
    <script src="assets/js/plugins/slicknav.min.js"></script>

    <!--=== Mian Js ===-->
    <script src="assets/js/main.js"></script>

</body>

</html>