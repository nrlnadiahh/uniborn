<?php
    include 'conn.php';
    $conn1 = OpenCon();
    session_start();
    

    $user_check = $_SESSION['login_user'];
    
    $sql="select * from renter where renterid = $user_check";

    $result = $conn1->query($sql);

    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $login_id = $row['renterid'];
            $login_name = $row['rentername'];
        }
    } else {
            header("location:renterlogin.php");
            die();
    }
    CloseCon($conn1);
    ?>