<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
<?php include 'head.php'; ?>
<script type="text/javascript">
			function confirmDelete(bookingid)
			{
				if(confirm('Sure To Remove This Record ?'))
				{
					window.location.href='deletebooking.php?bookingid='+bookingid;
				}
			}
		</script>
</head>

<body class="loader-active">

    

    <!--== Header Area Start ==-->
    <?php include 'header.php'; ?>
    <!--== Header Area End ==-->

    <!--== Page Title Area Start ==-->
    <section id="page-title-area" class="section-padding overlay">
        <div class="container">
            <div class="row">
                <!-- Page Title Start -->
                <div class="col-lg-12">
                    <div class="section-title  text-center">
                        <h2>Booking Summary</h2>
                        <span class="title-line"><i class="fa fa-car"></i></span>
                        <p>Our mission is to provide high-quality cars for our customers.</p>
                    </div>
                </div>
                <!-- Page Title End -->
            </div>
        </div>
    </section>
    <!--== Page Title Area End ==-->

    <!--== Car List Area Start ==-->
    <section id="car-list-area" class="section-padding">
        <div class="container">
            <div class="row">
                <!-- Sidebar Area Start -->
                <div class="col-lg-4">
                    <div class="sidebar-content-wrap">
                        <!-- Single Sidebar Start -->
                        <div class="single-sidebar">
                            <h3>For More Informations</h3>

                            <div class="sidebar-body">
                                <p><i class="fa fa-mobile"></i> +6075953074</p>
                                <p><i class="fa fa-clock-o"></i> Mon-Fri 07.00 a.m. - 10.00 p.m.</p>
                            </div>
                        </div>
                        <!-- Single Sidebar End -->


                        <!-- Single Sidebar Start -->
                        <div class="single-sidebar">
                            <h3>Connect with Us</h3>

                            <div class="sidebar-body">
                                <div class="social-icons text-center">
                                    <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
                                    <a href="#" target="_blank"><i class="fa fa-instagram"></i></a>
                                    
                                </div>
                            </div>
                        </div>
                        <!-- Single Sidebar End -->
                    </div>
                </div>
                <!-- Sidebar Area End -->
                <!-- Car List Content Start -->
                <div class="col-lg-8">
                    <div class="car-list-content m-t-50">
                    <?php
                        $conn = OpenCon();
		
                        $bookingid = $_POST["bookingid"];
                        $bookdate = $_POST["bookdate"];
                        $timein = $_POST["timein"];
                        $timeout = $_POST["timeout"];
                        $picklocation = $_POST["picklocation"];

                       
                        $sql= "update booking
                                set bookdate='$bookdate',
                                    timein = '$timein',
                                    timeout = '$timeout',
                                    picklocation = '$picklocation'
                               where bookingid = '$bookingid';";
                                
                        $result= $conn->query($sql);
                        
                        $sql2 = "select * 
                                from booking b, renter r, vehicle v
                                where b.renterid = r.renterid
                                and b.platno = v.platno
                                and bookingid = '$bookingid'";

			            $result= $conn->query($sql2);
						
						if($result->num_rows>0) {
                            while($row=$result->fetch_assoc()) {
                                $bookingid = $row["bookingid"];			
                                $bookdate = $row["bookdate"];			
                                $timein = $row["timein"];
                                $timeout = $row["timeout"];
                                $picklocation = $row["picklocation"];
                                $status = $row["status"];

                               ?> <?php
                                        function differenceInHours($timein,$timeout){
                                        $starttimestamp = strtotime($timein);
                                        $endtimestamp = strtotime($timeout);
                                        $difference = abs($endtimestamp - $starttimestamp)/3600;
                                        return $difference;
                                    }

	                        $totalprice = (differenceInHours($row["timein"],$row["timeout"]))* $row["pricehour"];	

                             ?><?php
                                $renterid = $row["renterid"];
                                $rentername = $row["rentername"];
                                $icnum = $row["icnum"];
                                $phonenum = $row["phonenum"];
                                $licensenum = $row["licensenum"];
                                $email = $row["email"];
                                $platno = $row["platno"];
                                $model = $row["model"];
                                $mode = $row["mode"];
                                $type = $row["type"];
                                $seatcap = $row["seatcap"];
                                $pricehour = $row["pricehour"];

                                
                        
                            }
                            $sql3= "update booking
                            set totalprice = '$totalprice'
                        where bookingid = '$bookingid';";
                
                $result= $conn->query($sql3);

                                ?> <!--== FAQ Area Start ==-->
                                <section id="faq-page-area" >
                                    <div class="container">
                                        <div class="row1">
                                            <!-- FAQ Content Start -->
                                            <div class="col-lg-8">
                                                <div class="faq-details-content">
                                                    <!-- Single FAQ Subject  Start -->
                                                    <div class="single-faq-sub">
                                                        <h3>Booking Summary</h3>
                                                        <div class="single-faq-sub-content">
                                                            <div id="accordion">
                                                                <!-- Single FAQ Start -->
                                                                <div class="card">
                                                                    <div class="card-header" id="headingOne">
                                                                        <h5 class="mb-0"><button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                                            <span>Personal Information</span>
                                                                            <i class="fa fa-angle-down"></i>
                                                                            <i class="fa fa-angle-up"></i>
                                                                        </button></h5>
                                                                    </div>
                            
                                                                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                                                        <div class="card-body">
                                                                           <b>RENTER ID :</b><?php echo " $renterid";?> 
                                                                           <br><b>RENTER NAME :</b><?php echo " $rentername";?>
                                                                           <br><b>IC NUMBER :</b><?php echo " $icnum";?>
                                                                           <br><b>LICENSE NUMBER :</b><?php echo " $licensenum";?>
                                                                           <br><b>PHONE NUMBER :</b><?php echo " $phonenum";?>
                                                                           <br><b>EMAIL :</b><?php echo " $email";?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <!-- Single FAQ End -->
                                                                
                                                                <!-- Single FAQ Start -->
                                                                <div class="card">
                                                                    <div class="card-header" id="headingTwo">
                                                                        <h5 class="mb-0"><button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                                              <span>Booking Information</span>
                                                                            <i class="fa fa-angle-down"></i>
                                                                            <i class="fa fa-angle-up"></i>
                                                                          </button></h5>
                                                                    </div>
                                                                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                                                        <div class="card-body">
                                                                           <b>BOOKING ID :</b><?php echo " $bookingid";?> 
                                                                           <br><b>BOOKING DATE :</b><?php echo " $bookdate";?>
                                                                           <br><b>PICK-UP LOCATION :</b><?php echo " $picklocation";?>
                                                                           <br><b>TIME IN :</b><?php echo " $timein";?>
                                                                           <br><b>TIME OUT :</b><?php echo " $timeout";?>
                                                                           <br><b>TOTAL PRICE :</b> RM<?php echo "$totalprice";?>
                                                                           <br><b>STATUS :</b><?php echo " $status";?>                                                                    </div>
                                                                    </div>
                                                                </div>
                                                                <!-- Single FAQ Start -->
                                                                
                                                                <!-- Single FAQ End -->
                                                                <div class="card">
                                                                    <div class="card-header" id="headingThree">
                                                                        <h5 class="mb-0"><button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                                              <span>Car Information</span>
                                                                            <i class="fa fa-angle-down"></i>
                                                                            <i class="fa fa-angle-up"></i>
                                                                        </button></h5>
                                                                    </div>
                                                                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                                                        <div class="card-body">
                                                                            <b>PLAT NO :</b><?php echo " $platno";?> 
                                                                            <br><b>PRICE PER HOUR :</b> RM<?php echo " $pricehour";?> 
                                                                            <br><b>SEAT CAPACITY :</b><?php echo " $seatcap";?> 
                                                                           <br><b>MODEL :</b><?php echo " $model";?>
                                                                           <br><b>MODE :</b><?php echo " $mode";?>
                                                                           <br><b>TYPE:</b><?php echo " $type";?>                                                                         </div>
                                                                    </div>
                                                                </div>
                                                                <!-- Single FAQ End -->
                                                                 <?php if($status == "Pending") {
                                                                     ?>
                                                                     <div class="input-submit1">
                                                                       <button onclick="window.location.href='updatedriverdetails.php?bookingid=<?php echo $bookingid ?>'">UPDATE</button>
                                                                       <button value="Delete" onclick="confirmDelete('<?php echo $bookingid ?>')">DELETE</button>
                                                                 </div>
                                                                 <?php } 
                                                                 
                                                                    else {
                                                                     ?><button value="Home" onclick="window.location.href='index.php'">HOME</button>
                                                                 <?php } ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- Single FAQ Subject End -->
                                                </div>
                                            </div> 
                                             <!-- FAQ Content End --><?php
                                            }

                                            else { echo "<center><h>No booking found. Start booking now for more travelling adventures!</h></center>"; }
                                           
                                            CloseCon($conn);
                                            ?>
                        <!-- Single Car End --> 
                                
                             
                            </div>
                  
                </div>
                <!-- Car List Content End -->
                                
                                
            </div>
        </div>
    </section>
    <!--== Car List Area End ==-->

      <!--== Footer Area Start ==-->
      <?php include'footer.php' ?>
    <!--== Footer Area End ==-->

    <!--== Scroll Top Area Start ==-->
    <div class="scroll-top">
        <img src="assets/img/scroll-top.png" alt="JSOFT">
    </div>
    <!--== Scroll Top Area End ==-->

    <!--=======================Javascript============================-->
    <!--=== Jquery Min Js ===-->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <!--=== Jquery Migrate Min Js ===-->
    <script src="assets/js/jquery-migrate.min.js"></script>
    <!--=== Popper Min Js ===-->
    <script src="assets/js/popper.min.js"></script>
    <!--=== Bootstrap Min Js ===-->
    <script src="assets/js/bootstrap.min.js"></script>
    <!--=== Gijgo Min Js ===-->
    <script src="assets/js/plugins/gijgo.js"></script>
    <!--=== Vegas Min Js ===-->
    <script src="assets/js/plugins/vegas.min.js"></script>
    <!--=== Isotope Min Js ===-->
    <script src="assets/js/plugins/isotope.min.js"></script>
    <!--=== Owl Caousel Min Js ===-->
    <script src="assets/js/plugins/owl.carousel.min.js"></script>
    <!--=== Waypoint Min Js ===-->
    <script src="assets/js/plugins/waypoints.min.js"></script>
    <!--=== CounTotop Min Js ===-->
    <script src="assets/js/plugins/counterup.min.js"></script>
    <!--=== YtPlayer Min Js ===-->
    <script src="assets/js/plugins/mb.YTPlayer.js"></script>
    <!--=== Magnific Popup Min Js ===-->
    <script src="assets/js/plugins/magnific-popup.min.js"></script>
    <!--=== Slicknav Min Js ===-->
    <script src="assets/js/plugins/slicknav.min.js"></script>

    <!--=== Mian Js ===-->
    <script src="assets/js/main.js"></script>

</body>

</html>