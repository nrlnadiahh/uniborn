<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
<?php include 'head.php'; ?>
</head>

<body class="loader-active">

      <!--== Preloader Area Start ==-->
      <div class="preloader">
        <div class="preloader-spinner">
            <div class="loader-content">
                <img src="assets/img/preloader.gif" alt="JSOFT">
            </div>
        </div>
    </div>
    <!--== Preloader Area End ==-->

    <!--== Header Area Start ==-->
    <?php include 'header.php'; ?>
    <!--== Header Area End ==-->

    <!--== Page Title Area Start ==-->
    <section id="page-title-area" class="section-padding overlay">
        <div class="container">
            <div class="row">
                <!-- Page Title Start -->
                <div class="col-lg-12">
                    <div class="section-title  text-center">
                        <h2>List of Cars</h2>
                        <span class="title-line"><i class="fa fa-car"></i></span>
                        <p>Our mission is to provide high-quality cars for our customers.</p>
                    </div>
                </div>
                <!-- Page Title End -->
            </div>
        </div>
    </section>
    <!--== Page Title Area End ==-->

    <!--== Car List Area Start ==-->
    <section id="car-list-area" class="section-padding">
        <div class="container">
            <div class="row">
                <!-- Sidebar Area Start -->
                <div class="col-lg-4">
                    <div class="sidebar-content-wrap">
                        <!-- Single Sidebar Start -->
                        <div class="single-sidebar">
                            <h3>For More Informations</h3>

                            <div class="sidebar-body">
                                <p><i class="fa fa-mobile"></i> +6075953074</p>
                                <p><i class="fa fa-clock-o"></i> Mon-Fri 07.00 a.m. - 10.00 p.m.</p>
                            </div>
                        </div>
                        <!-- Single Sidebar End -->


                        <!-- Single Sidebar Start -->
                        <div class="single-sidebar">
                            <h3>Connect with Us</h3>

                            <div class="sidebar-body">
                                <div class="social-icons text-center">
                                    <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
                                    <a href="#" target="_blank"><i class="fa fa-instagram"></i></a>
                                    
                                </div>
                            </div>
                        </div>
                        <!-- Single Sidebar End -->
                    </div>
                </div>
                <!-- Sidebar Area End -->
                <!-- Car List Content Start -->
                <div class="col-lg-8">
                    <div class="car-list-content m-t-50">
                <?php

                                                $permitted_chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
                                                
                                                        function generate_string($input, $strength = 16) {
                                                        $input_length = strlen($input);
                                                        $random_string = '';
                                                        for($i = 0; $i < $strength; $i++) {
                                                            $random_character = $input[mt_rand(0, $input_length - 1)];
                                                            $random_string .= $random_character;
                                                        }
                                                
                                                    return $random_string;
                                                }

                                                $bookingid = generate_string($permitted_chars, 6);
                                                $picklocation = $_POST["picklocation"];
                                                $bookdate = $_POST["bookdate"];
                                                $timein = $_POST["timein"];
                                                $timeout = $_POST["timeout"];
                                                $renterid = $login_id;

                                    
                                                $conn = OpenCon();
                                                $sql = "INSERT INTO booking (bookingid,bookdate,timein,timeout,picklocation,status,totalprice,renterid,platno,staffid)
                                                        VALUES ('$bookingid', '$bookdate', '$timein', '$timeout', '$picklocation', 'Pending', 'null', '$renterid', '1000', 'S14041')";
                                                if(mysqli_query($conn, $sql)) {
                                                            	echo "New record ";
                                                            //display back all the data that has been inserted.
                                                                 
                                                $sql2 = "select *
                                                        from vehicle
                                                        where platno NOT IN
                                                                (select platno
                                                                 from booking
                                                                 where bookdate = '$bookdate'
                                                                 and timein = '$timein')";
                                                $result = $conn->query($sql2);

                                                if($result->num_rows>0) {
                                                	while($row=$result->fetch_assoc()) 
                                                    {		
                                                $platno = $row["platno"];	        
                                                $model = $row["model"];			
                                                $mode = $row["mode"];
                                                $type = $row["type"];
                                                $seatcap = $row["seatcap"];
                                                $pricehour = $row["pricehour"];
                                                      
              ?>  
                        <!-- Single Car Start -->
                        <div class="single-car-wrap">
                            <div class="row">
                                <!-- Single Car Thumbnail -->
                                <div class="col-lg-5"><?php
                                    if($model == "Myvi")
                                    {
                                        ?><div class="car-list-thumb car-thumb-myvi"></div><?php
                                    }
                                    else if($model == "Axia")
                                    {
                                        ?><div class="car-list-thumb car-thumb-axia"></div><?php
                                    }
                                    else if($model == "Saga")
                                    {
                                        ?><div class="car-list-thumb car-thumb-saga"></div><?php
                                    }
                                    else if($model == "Iriz")
                                    {
                                        ?><div class="car-list-thumb car-thumb-iriz"></div><?php
                                    }
                                    else if($model == "Exora")
                                    {
                                        ?><div class="car-list-thumb car-thumb-exora"></div><?php
                                    }
                                    else if($model == "Alza")
                                    {
                                        ?><div class="car-list-thumb car-thumb-alza"></div><?php
                                    }
                                
                                    ?>
                                </div>
                                <!-- Single Car Thumbnail -->

                                <!-- Single Car Info -->
                                <div class="col-lg-7">
                                    <div class="display-table">
                                        <div class="display-table-cell">
                                            <div class="car-list-info"><?php
                                               

                                                echo "<h2>$model</h2>"; 
                                                echo "<h5>RM " .$pricehour. " RENT/ PER HOUR </h5>";
                                                echo "<p>Type : " .$type. "<br>Seat Capacity : " .$seatcap;
                                                echo "<ul class='car-info-list'>
                                                            <li>Air Condition</li>
                                                            <li>Diesel</li>
                                                            <li>Auto</li>
                                                        </ul>";

                                       echo" <p class='rating'>
                                            <i class='fa fa-star'></i>
                                            <i class='fa fa-star'></i>
                                            <i class='fa fa-star'></i>
                                            <i class='fa fa-star'></i>
                                            <i class='fa fa-star unmark'></i>
                                        </p>";
                                        ?> <input type="button"  class="rent-btn" value="Book Now" onclick="window.location.href='displaydriverdetails.php?bookingid=<?php echo $bookingid; ?>&platno=<?php echo $platno; ?>' " /> 
                                        
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Single Car info -->
                            </div>
                        </div>
                        <!-- Single Car End --> <?php

                                    }
                                }
                                
                                else 
                                    echo "Error in ferching data";
                                     }
                                                        else {
                                                            echo "Error : " . $sql. "<br>" . mysqli_error($conn);
                                                        }

                                CloseCon($conn);?>
                                
                       
                            </div>
                  
                </div>
                <!-- Car List Content End -->
                                
                                
            </div>
        </div>
    </section>
    <!--== Car List Area End ==-->

      <!--== Footer Area Start ==-->
      <?php include'footer.php' ?>
    <!--== Footer Area End ==-->

    <!--== Scroll Top Area Start ==-->
    <div class="scroll-top">
        <img src="assets/img/scroll-top.png" alt="JSOFT">
    </div>
    <!--== Scroll Top Area End ==-->

    <!--=======================Javascript============================-->
    <!--=== Jquery Min Js ===-->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <!--=== Jquery Migrate Min Js ===-->
    <script src="assets/js/jquery-migrate.min.js"></script>
    <!--=== Popper Min Js ===-->
    <script src="assets/js/popper.min.js"></script>
    <!--=== Bootstrap Min Js ===-->
    <script src="assets/js/bootstrap.min.js"></script>
    <!--=== Gijgo Min Js ===-->
    <script src="assets/js/plugins/gijgo.js"></script>
    <!--=== Vegas Min Js ===-->
    <script src="assets/js/plugins/vegas.min.js"></script>
    <!--=== Isotope Min Js ===-->
    <script src="assets/js/plugins/isotope.min.js"></script>
    <!--=== Owl Caousel Min Js ===-->
    <script src="assets/js/plugins/owl.carousel.min.js"></script>
    <!--=== Waypoint Min Js ===-->
    <script src="assets/js/plugins/waypoints.min.js"></script>
    <!--=== CounTotop Min Js ===-->
    <script src="assets/js/plugins/counterup.min.js"></script>
    <!--=== YtPlayer Min Js ===-->
    <script src="assets/js/plugins/mb.YTPlayer.js"></script>
    <!--=== Magnific Popup Min Js ===-->
    <script src="assets/js/plugins/magnific-popup.min.js"></script>
    <!--=== Slicknav Min Js ===-->
    <script src="assets/js/plugins/slicknav.min.js"></script>

    <!--=== Mian Js ===-->
    <script src="assets/js/main.js"></script>

</body>

</html>