<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
<?php include 'head.php'; ?>
</head>

<body class="loader-active">

    

    <!--== Header Area Start ==-->
    <?php include 'header.php'; ?>
    <!--== Header Area End ==-->

    <!--== Page Title Area Start ==-->
    <section id="page-title-area" class="section-padding overlay">
        <div class="container">
            <div class="row">
                <!-- Page Title Start -->
                <div class="col-lg-12">
                    <div class="section-title  text-center">
                        <h2>Booking Details</h2>
                        <span class="title-line"><i class="fa fa-car"></i></span>
                        <p>Our mission is to provide high-quality cars for our customers.</p>
                    </div>
                </div>
                <!-- Page Title End -->
            </div>
        </div>
    </section>
    <!--== Page Title Area End ==-->

    <!--== Car List Area Start ==-->
    <section id="car-list-area" class="section-padding">
        <div class="container">
            <div class="row">
                <!-- Sidebar Area Start -->
                <div class="col-lg-4">
                    <div class="sidebar-content-wrap">
                        <!-- Single Sidebar Start -->
                        <div class="single-sidebar">
                            <h3>For More Informations</h3>

                            <div class="sidebar-body">
                                <p><i class="fa fa-mobile"></i> +6075953074</p>
                                <p><i class="fa fa-clock-o"></i> Mon-Fri 07.00 a.m. - 10.00 p.m.</p>
                            </div>
                        </div>
                        <!-- Single Sidebar End -->


                        <!-- Single Sidebar Start -->
                        <div class="single-sidebar">
                            <h3>Connect with Us</h3>

                            <div class="sidebar-body">
                                <div class="social-icons text-center">
                                    <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
                                    <a href="#" target="_blank"><i class="fa fa-instagram"></i></a>
                                    
                                </div>
                            </div>
                        </div>
                        <!-- Single Sidebar End -->
                    </div>
                </div>
                <!-- Sidebar Area End -->
                <!-- Car List Content Start -->
                <div class="col-lg-8">
                    <div class="car-list-content m-t-50">
                    <?php
                        $conn = OpenCon();

                        $bookingid = $_GET["bookingid"];
		
                        $sql= " select *
                                from booking b, renter r, vehicle v, staff s
                                where b.renterid = r.renterid
                                and b.staffid = s.staffid
                                and b.platno = v.platno
                                and bookingid = '$bookingid'";
                                
						$result= $conn->query($sql);
						
						if($result->num_rows>0) {
                            while($row=$result->fetch_assoc()) {
                                $bookingid = $row["bookingid"];			
                                $bookdate = $row["bookdate"];			
                                $timein = $row["timein"];
                                $timeout = $row["timeout"];
                                $picklocation = $row["picklocation"];
                                $status = $row["status"];
                                $renterid = $row["renterid"];
                                $platno = $row["platno"];
                            }
                                ?><!-- Single Car Start -->
                                <div class="single-car-wrap">
                                    <div class="row1">
                                    <div class="review-area">
                                        <h3>Please Check Your Booking Details</h3>
                                        <div class="review-form">
                                            <form action="updatebooking.php" id="updateform" method="POST">
                                                <div class="row">
                                                    <div class="col-lg-6 col-md-6">
                                                        <div class="name-input">
                                                            <h6>Booking ID</h6>
                                                            <input type="text" name="bookingid" value="<?php echo $bookingid;?>" readonly>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-lg-6 col-md-6">
                                                        <div class="email-input">
                                                            <h6>Booking Date</h6>
                                                            <input type="date" name="bookdate" min="<?= date('Y-m-d'); ?>" value="<?php echo $bookdate;?>" >
                                                        </div>
                                                    </div>


                                                    <div class="col-lg-7 col-md-7">
                                                        <div class="name-input">
                                                        <h6>Time In</h6>
                                                             <input type="time" name="timein" value="<?php echo $timein;?>" >
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-lg-7 col-md-7">
                                                        <div class="email-input">
                                                        <h6>Time Out</h6>
                                                             <input type="time" name="timeout" value="<?php echo $timeout;?>" >
                                                        </div>
                                                    </div>

                                                    <div class="col-lg-6 col-md-6">
                                                        <div class=pick-location bookinput-item>
                                                        <h6>Pick Up Location</h6>
                                                             <select id="picklocation" name="picklocation">
                                                                <option value="Bus Terminal" <?php if($picklocation == "Bus Terminal") echo "SELECTED"; ?>>Bus Terminal</option>
                                                                <option value="International Airport" <?php if($picklocation == "International Airport") echo "SELECTED"; ?>>International Airport</option>
                                                                <option value="Ferry Terminal" <?php if($picklocation == "Ferry Terminal") echo "SELECTED"; ?>>Ferry Terminal</option>
                                                                <option value="Self Collect at Center" <?php if($picklocation == "Self Collect at Center") echo "SELECTED"; ?>>Self Collect at Center</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <?php
                                                
                                            }else {
                                                    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
                                                }
                                                //	}
                                                CloseCon($conn);
                                                                    ?> 
                                           <div class="input-submit">
                                            <button type="submit">Confirm</button>
                                        </div>    
                                        </div>

                                    </form>
                                </div>
                            </div>
                               

                            </div>
                        </div>
                        <!-- Single Car End --> 
                                
                             
                            </div>
                  
                </div>
                <!-- Car List Content End -->
                                
                                
            </div>
        </div>
    </section>
    <!--== Car List Area End ==-->

      <!--== Footer Area Start ==-->
      <?php include'footer.php' ?>
    <!--== Footer Area End ==-->

    <!--== Scroll Top Area Start ==-->
    <div class="scroll-top">
        <img src="assets/img/scroll-top.png" alt="JSOFT">
    </div>
    <!--== Scroll Top Area End ==-->

    <!--=======================Javascript============================-->
    <!--=== Jquery Min Js ===-->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <!--=== Jquery Migrate Min Js ===-->
    <script src="assets/js/jquery-migrate.min.js"></script>
    <!--=== Popper Min Js ===-->
    <script src="assets/js/popper.min.js"></script>
    <!--=== Bootstrap Min Js ===-->
    <script src="assets/js/bootstrap.min.js"></script>
    <!--=== Gijgo Min Js ===-->
    <script src="assets/js/plugins/gijgo.js"></script>
    <!--=== Vegas Min Js ===-->
    <script src="assets/js/plugins/vegas.min.js"></script>
    <!--=== Isotope Min Js ===-->
    <script src="assets/js/plugins/isotope.min.js"></script>
    <!--=== Owl Caousel Min Js ===-->
    <script src="assets/js/plugins/owl.carousel.min.js"></script>
    <!--=== Waypoint Min Js ===-->
    <script src="assets/js/plugins/waypoints.min.js"></script>
    <!--=== CounTotop Min Js ===-->
    <script src="assets/js/plugins/counterup.min.js"></script>
    <!--=== YtPlayer Min Js ===-->
    <script src="assets/js/plugins/mb.YTPlayer.js"></script>
    <!--=== Magnific Popup Min Js ===-->
    <script src="assets/js/plugins/magnific-popup.min.js"></script>
    <!--=== Slicknav Min Js ===-->
    <script src="assets/js/plugins/slicknav.min.js"></script>

    <!--=== Mian Js ===-->
    <script src="assets/js/main.js"></script>

</body>

</html>