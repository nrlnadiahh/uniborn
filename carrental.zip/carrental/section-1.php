<!-- <header class="mb-4"><h1 class="tm-text-shadow">Constructive Design</h1></header>
							<p class="mb-5 tm-font-big">Aenean fermentum vestibulum ipsum, ut pretium erat sodales sodales. Pellentesque quis orci vitae dui commodo sodales et ut quam. Etiam vitae egestas purus, ut malesuada enim.</p>
							<a href="#" class="btn tm-btn tm-font-big" data-nav-link="#tmNavLink2">Continue...</a> 
                            data-nav-link holds the ID of nav item, which means this link should behave the same as that nav item -->
<div class="ml-auto">                            
    <header class="mb-4"><h1 class="tm-text-shadow">Welcome</h1></header>
    <p class="mb-5 tm-font-big">Hi, welcome back to our system! <br>"We do everything with our core values of honest , hard work and trust."</p>
    <a href="#" class="btn tm-btn tm-font-big" data-nav-link="#tmNavLink2">Continue...</a>                            
</div>