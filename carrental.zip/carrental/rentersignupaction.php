<?php
                    include 'conn.php';
					$rentername = $_POST["rentername"];
					$icnum = $_POST["icnum"];
					$phonenum = $_POST["phonenum"];
					$licensenum = $_POST["licensenum"];
					$address= $_POST["address"];
					$email= $_POST["email"];
					$password = $_POST["password"];

					$permitted_chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
                                                
					function generate_string($input, $strength = 16) {
					$input_length = strlen($input);
					$random_string = '';
					for($i = 0; $i < $strength; $i++) {
						$random_character = $input[mt_rand(0, $input_length - 1)];
						$random_string .= $random_character;
					}
					
						return $random_string;
					}

					$renterid = generate_string($permitted_chars, 6);

					$conn = OpenCon();
					$sql = "INSERT INTO renter (renterid,rentername, icnum, phonenum, address, licensenum, email,password)
							VALUES ('$renterid', '$rentername', '$icnum', '$phonenum', '$address', $licensenum, '$email', '$password')";
					   
					if(mysqli_query($conn, $sql)) { 
						
						$message = "Successful! Your Renter ID is ";
						echo ("<script type='text/javascript'>alert('$message$renterid');window.location.href='renterlogin.php';</script>");
					}
					?>