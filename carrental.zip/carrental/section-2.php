<!-- <header class="mb-4"><h2 class="tm-text-shadow">Our Products</h2></header>		            
<div class="tm-img-container">
								<div class="tm-img-slider">
									<a href="img/gallery-img-01.jpg" class="tm-slider-img"><img src="img/gallery-img-01-tn.jpg" alt="Image" class="img-fluid"></a>
									<a href="img/gallery-img-02.jpg" class="tm-slider-img"><img src="img/gallery-img-02-tn.jpg" alt="Image" class="img-fluid"></a>
									<a href="img/gallery-img-03.jpg" class="tm-slider-img"><img src="img/gallery-img-03-tn.jpg" alt="Image" class="img-fluid"></a>
									<a href="img/gallery-img-04.jpg" class="tm-slider-img"><img src="img/gallery-img-04-tn.jpg" alt="Image" class="img-fluid"></a>
									<a href="img/gallery-img-05.jpg" class="tm-slider-img"><img src="img/gallery-img-05-tn.jpg" alt="Image" class="img-fluid"></a>
									<a href="img/gallery-img-06.jpg" class="tm-slider-img"><img src="img/gallery-img-06-tn.jpg" alt="Image" class="img-fluid"></a>
								</div>
                            </div>	-->
<div class="tm-bg-transparent-black tm-contact-box-pad">
    <div class="row mb-4">
		<div class="col-sm-12">
			<center><h2 class="tm-text-shadow2"><b>Booking Status</b></h2></center>
			<br>
			
				
			<a href="completed.php" class="btn tm-btn1 tm-font-big" data-nav-link="#tmNavLink2">Completed</a>  
			<a href="pending 1.php" class="btn tm-btn1 tm-font-big" data-nav-link="#tmNavLink2">Pending</a>    
			<a href="rejected.php" class="btn tm-btn1 tm-font-big" data-nav-link="#tmNavLink2">Rejected</a>   
		
		</div>
	</div>
</div>                            