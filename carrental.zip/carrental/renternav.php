<li>
    <a href="home.php" id="tmNavLink1" class="scrolly" data-bg-img="banner2.jpg" data-page="#tm-section-1">
        <i class="fas fa-home tm-nav-fa-icon"></i>
        <span>About Us</span>
	</a>
</li>
<li>
    <a href="#customer" id="tmNavLink2" class="scrolly <?php if($_SERVER['SCRIPT_NAME']=="/carrental/pending.php") echo "active"; ?>" data-bg-img="banner2.jpg" data-page="#tm-section-2" data-page-type="carousel">
        <i class="fas fa-book tm-nav-fa-icon"></i>
        <span>Make Booking</span>
    </a>
</li>							
<li>
    <a href="#company" class="scrolly" data-bg-img="banner2.jpg" data-page="#tm-section-3">
        <i class="fas fa-user tm-nav-fa-icon"></i>
        <span>My Profile</span>
    </a>
</li>
<li>
    <a href="#contact" class="scrolly" data-bg-img="banner2.jpg" data-page="#tm-section-4">
        <i class="fas fa-phone tm-nav-fa-icon"></i>
        <span>Contact Us</span>
	</a>
</li>
<li>
    <a href="#company" class="scrolly" data-bg-img="banner2.jpg" data-page="#tm-section-5">
        <i class="fas fa-lock tm-nav-fa-icon"></i>
        <span>Log Out</span>
    </a>
</li>